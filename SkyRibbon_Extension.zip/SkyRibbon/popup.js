'use strict';
const $ = id => document.getElementById(id);
const cityInput = $('city-search');
const cityResults = $('city-results');
const unitButtons = [...document.querySelectorAll('[data-unit]')];
const appearanceButtons = [...document.querySelectorAll('[data-color-mode]')];
let colorMode = 'dynamic';
let latestForecast = null;
const refreshButton = $('refresh');
const locateButton = $('use-location');
let currentLocation = null;
let citySearchTimer = 0;
let searchSerial = 0;
let forecastSerial = 0;
let searchAbort = null;
const DEFAULT_LOCATION = {
  name: 'Denver', region: 'Colorado, United States', latitude: 39.7392,
  longitude: -104.9903, timezone: 'America/Denver', unit: 'fahrenheit'
};

function status(message, isError = false) {
  $('status').textContent = message;
  $('status').classList.toggle('error', isError);
}
function setUnitButtons(unit) {
  for (const b of unitButtons) b.setAttribute('aria-pressed', String(b.dataset.unit === unit));
}
function setAppearanceButtons(mode) {
  for (const b of appearanceButtons) b.setAttribute('aria-pressed', String(b.dataset.colorMode === mode));
}
function refreshCardPalette() {
  if (!latestForecast) return;
  const {location, data} = latestForecast;
  const index = data.daily.time.indexOf(localDate(data.timezone || location.timezone));
  if (index < 0) return;
  const theme = window.SkyRibbonWeatherTheme.getTheme(
    data.daily.weather_code[index], data.daily.temperature_2m_max[index], location.unit, colorMode
  );
  const card = $('today');
  card.style.setProperty('--sr-card-bg', theme.background);
  card.style.setProperty('--sr-card-text', theme.text);
  card.style.setProperty('--sr-card-muted', theme.muted);
  card.style.setProperty('--sr-card-border', theme.background);
  card.style.setProperty('--sr-card-glow', theme.text);
}

function describe(code) {
  code = Number(code);
  if (code === 0) return ['☀️','Sunny'];
  if (code === 1) return ['🌤️','Mostly sunny'];
  if (code === 2) return ['⛅','Partly cloudy'];
  if (code === 3) return ['☁️','Cloudy'];
  if (code === 45 || code === 48) return ['🌫️','Foggy'];
  if (code >= 51 && code <= 57) return ['🌦️','Drizzle'];
  if (code >= 61 && code <= 67) return ['🌧️','Rain'];
  if (code >= 71 && code <= 77) return ['❄️','Snow'];
  if (code >= 80 && code <= 82) return ['🌧️','Showers'];
  if (code === 85 || code === 86) return ['🌨️','Snow showers'];
  if (code >= 95 && code <= 99) return ['⛈️','Thunderstorms'];
  return ['🌡️','Forecast'];
}
function localDate(timezone) {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date());
    const map = Object.fromEntries(parts.map(p => [p.type, p.value]));
    return `${map.year}-${map.month}-${map.day}`;
  } catch { return new Date().toISOString().slice(0, 10); }
}
function displayLocation(location) {
  currentLocation = location;
  const place = [location.name, location.region?.split(',')[0]].filter(Boolean).join(', ');
  $('city-label').textContent = `📍 ${place}`;
  setUnitButtons(location.unit);
}
function displayForecast(response) {
  latestForecast = response;
  const {location, data} = response;
  displayLocation(location);
  const d = data.daily;
  const index = d.time.indexOf(localDate(data.timezone || location.timezone));
  if (index === -1) {
    $('today').textContent = 'Forecast unavailable for today';
    return;
  }
  const [emoji, label] = describe(d.weather_code[index]);
  const low = Math.round(d.temperature_2m_min[index]);
  const high = Math.round(d.temperature_2m_max[index]);
  const row = document.createElement('div'); row.className = 'weather-row';
  const icon = document.createElement('span'); icon.className = 'forecast-emoji'; icon.textContent = emoji;
  const numbers = document.createElement('span'); numbers.className = 'weather-numbers';
  numbers.textContent = `${low}° / ${high}°`;
  row.append(icon, numbers);
  const desc = document.createElement('span'); desc.className = 'weather-desc';
  desc.textContent = `${label} today · Low / High${response.stale ? ' · Saved forecast' : ''}`;
  $('today').replaceChildren(row, desc);
  refreshCardPalette();
}
function loadForecast(force = false) {
  const serial = ++forecastSerial;
  refreshButton.disabled = true;
  status('Updating forecast…');
  chrome.runtime.sendMessage({type:'DCW_GET_FORECAST',force}, response => {
    if (serial !== forecastSerial) return;
    refreshButton.disabled = false;
    const error = chrome.runtime.lastError?.message || response?.error;
    if (error || !response?.data) {
      status(error || 'Forecast temporarily unavailable. Try refreshing.', true);
      return;
    }
    displayForecast(response);
    status('Your forecast is up to date.');
  });
}
async function saveLocation(next) {
  try {
    await chrome.storage.local.set({srLocation: next});
    displayLocation(next);
    cityInput.value = '';
    hideResults();
    loadForecast(true);
  } catch (error) {
    status(`Couldn't save location: ${error.message || error}`, true);
  }
}
function hideResults() {
  cityResults.hidden = true;
  cityInput.setAttribute('aria-expanded','false');
}
function showResults() {
  cityResults.hidden = false;
  cityInput.setAttribute('aria-expanded','true');
}
function renderCities(cities) {
  cityResults.replaceChildren();
  if (!cities.length) {
    const p = document.createElement('p'); p.className = 'empty'; p.textContent = 'No matching cities. Try another search.';
    cityResults.append(p);
  }
  for (const city of cities) {
    if (!Number.isFinite(city.latitude) || !Number.isFinite(city.longitude) || !city.timezone) continue;
    const button = document.createElement('button');
    button.type = 'button'; button.setAttribute('role','option');
    button.textContent = [city.name,city.admin1,city.country].filter(Boolean).join(', ');
    button.addEventListener('click',() => {
      searchSerial++; // Discard any older searches that complete after selection.
      searchAbort?.abort();
      saveLocation({
        name:city.name, region:[city.admin1,city.country].filter(Boolean).join(', '),
        latitude:Number(city.latitude), longitude:Number(city.longitude),
        timezone:city.timezone, unit:currentLocation?.unit || 'fahrenheit'
      });
    });
    cityResults.append(button);
  }
  showResults();
}
cityInput.addEventListener('input', () => {
  clearTimeout(citySearchTimer);
  searchAbort?.abort();
  const serial = ++searchSerial;
  const term = cityInput.value.trim();
  hideResults(); cityResults.replaceChildren();
  if (term.length < 2) return;
  citySearchTimer = setTimeout(async () => {
    const controller = new AbortController(); searchAbort = controller;
    try {
      const url = new URL('https://geocoding-api.open-meteo.com/v1/search');
      url.search = new URLSearchParams({name:term,count:'7',language:'en',format:'json'});
      const response = await fetch(url,{signal:controller.signal});
      if (!response.ok) throw new Error('Search unavailable');
      const result = await response.json();
      if (serial !== searchSerial) return;
      renderCities(result.results || []);
    } catch(error) {
      if (error.name !== 'AbortError' && serial === searchSerial)
        status('City search is temporarily unavailable. Try again.',true);
    }
  }, 280);
});
cityInput.addEventListener('keydown', e => {
  if (e.key === 'Escape') {hideResults();cityInput.blur();}
  if (e.key === 'ArrowDown' && !cityResults.hidden) {
    const first = cityResults.querySelector('button');
    if (first) {e.preventDefault();first.focus();}
  }
});
cityResults.addEventListener('keydown', e => {
  const buttons=[...cityResults.querySelectorAll('button')];
  const index=buttons.indexOf(document.activeElement);
  if (e.key === 'ArrowDown' && buttons[index+1]) {e.preventDefault();buttons[index+1].focus();}
  else if (e.key === 'ArrowUp') {e.preventDefault();(buttons[index-1] || cityInput).focus();}
  else if (e.key === 'Escape') {hideResults();cityInput.focus();}
});
// Request location only after an explicit click. Chrome's geolocation permission
// is declared in the manifest; this popup never requests location at startup.
locateButton.addEventListener('click', () => {
  if (!navigator.geolocation) {
    status('Location detection is unavailable in this browser. Search for a city instead.', true);
    return;
  }
  locateButton.disabled = true;
  status('Detecting your location…');
  navigator.geolocation.getCurrentPosition(async position => {
    const latitude = Number(position.coords.latitude);
    const longitude = Number(position.coords.longitude);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      status('Location coordinates were unavailable. Search for a city instead.', true);
      locateButton.disabled = false;
      return;
    }
    let name = 'Current location';
    let region = '';
    // One optional reverse lookup, using only the live coordinates obtained
    // above. If it fails, the exact-coordinate forecast still works.
    try {
      status('Finding your nearest city…');
      const url = new URL('https://api.bigdatacloud.net/data/reverse-geocode-client');
      url.search = new URLSearchParams({ latitude:String(latitude), longitude:String(longitude), localityLanguage:'en' });
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6500);
      let response;
      try { response = await fetch(url, { signal:controller.signal }); }
      finally { clearTimeout(timeout); }
      if (response.ok) {
        const place = await response.json();
        name = place.city || place.locality || 'Current location';
        region = [place.principalSubdivision, place.countryName].filter(Boolean).join(', ');
      }
    } catch (_) { /* Remain on exact GPS coordinates if city-name lookup fails. */ }
    try {
      await saveLocation({
        name, region, latitude, longitude, timezone:'auto',
        unit:currentLocation?.unit || 'fahrenheit', detected:true
      });
      status(name === 'Current location' ? 'Using your detected coordinates.' : `Forecast set to ${name}.`);
    } finally { locateButton.disabled = false; }
  }, error => {
    locateButton.disabled = false;
    const message = error?.code === 1
      ? 'Location access was denied. Search for a city instead.'
      : error?.code === 3
        ? 'Location detection timed out. Search for a city or try again.'
        : 'Could not detect your location. Search for a city instead.';
    status(message, true);
  }, { enableHighAccuracy:false, timeout:13000, maximumAge:0 });
});

unitButtons.forEach(button => button.addEventListener('click', () => {
  if (!currentLocation || currentLocation.unit === button.dataset.unit) return;
  saveLocation({...currentLocation,unit:button.dataset.unit});
}));
appearanceButtons.forEach(button => button.addEventListener('click', async () => {
  const next = button.dataset.colorMode;
  if (next === colorMode) return;
  const previous = colorMode;
  colorMode = next;
  setAppearanceButtons(colorMode);
  refreshCardPalette();
  try {
    await chrome.storage.local.set({ srColorMode: colorMode });
    status(next === 'dynamic' ? 'Weather colors follow each day’s forecast.' : 'Classic blue badges are restored.');
  } catch(error) {
    colorMode = previous;
    setAppearanceButtons(colorMode);
    refreshCardPalette();
    status('Unable to save badge color setting.', true);
  }
}));
$('enabled').addEventListener('change', async e => {
  try {
    await chrome.storage.local.set({dcwEnabled:e.target.checked});
    status(e.target.checked ? 'Weather is visible in Calendar.' : 'Weather is hidden in Calendar.');
  } catch {status('Unable to save display setting.',true);}
});
refreshButton.addEventListener('click', () => loadForecast(true));
chrome.storage.local.get({dcwEnabled:true, srColorMode:'dynamic'}, obj => {
  $('enabled').checked = obj.dcwEnabled !== false;
  colorMode = obj.srColorMode === 'classic' ? 'classic' : 'dynamic';
  setAppearanceButtons(colorMode);
  refreshCardPalette();
});
chrome.runtime.sendMessage({type:'SR_GET_LOCATION'}, response => {
  if (chrome.runtime.lastError || response?.error) {
    displayLocation(DEFAULT_LOCATION);
    status('Using Denver until a city is selected.');
  } else displayLocation(response?.location || DEFAULT_LOCATION);
  loadForecast();
});
