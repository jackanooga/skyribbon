/* SkyRibbon forecast color system. Used by both the Calendar ribbon and popup.
   Open-Meteo returns WMO weather interpretation codes. */
(() => {
  'use strict';
  const themes = Object.freeze({
    classic: { name: 'Classic blue', background: '#405E9A', text: '#FFFFFF', muted: '#E2ECFF' },
    sunny:  { name: 'Sunny', background: '#F9D56E', text: '#443410', muted: '#6B511F' },
    partly: { name: 'Partly cloudy', background: '#BED5F2', text: '#1E3855', muted: '#345676' },
    cloudy: { name: 'Cloudy', background: '#657588', text: '#FFFFFF', muted: '#E3EAF3' },
    fog:    { name: 'Foggy', background: '#9DAEBC', text: '#172B43', muted: '#344C63' },
    drizzle:{ name: 'Drizzle', background: '#8BB9DF', text: '#193550', muted: '#315575' },
    rain:   { name: 'Rain', background: '#3775C4', text: '#FFFFFF', muted: '#EBF3FF' },
    snow:   { name: 'Snow', background: '#E8EFF6', text: '#243D58', muted: '#4F647A' },
    storm:  { name: 'Thunderstorms', background: '#68528F', text: '#FFFFFF', muted: '#EAE2F8' },
    cold:   { name: 'Freezing', background: '#A9D1F0', text: '#173B5F', muted: '#315D80' }
  });
  function category(code) {
    const c = Number(code);
    if (!Number.isFinite(c)) return 'classic';
    if (c >= 95 && c <= 99) return 'storm';
    if ((c >= 71 && c <= 77) || c === 85 || c === 86) return 'snow';
    if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return 'rain';
    if (c >= 51 && c <= 57) return 'drizzle';
    if (c === 45 || c === 48) return 'fog';
    if (c === 3) return 'cloudy';
    if (c === 1 || c === 2) return 'partly';
    if (c === 0) return 'sunny';
    return 'classic';
  }
  function getTheme(code, high, unit, mode = 'dynamic') {
    if (mode === 'classic') return { ...themes.classic, key: 'classic' };
    let key = category(code);
    // The whole day's high must stay at or below freezing. Precipitation
    // conditions take priority over cold so snow/rain/storm cues remain useful.
    const freezingHigh = Number(high);
    if (['sunny', 'partly', 'cloudy'].includes(key) && Number.isFinite(freezingHigh) &&
        freezingHigh <= (unit === 'celsius' ? 0 : 32)) key = 'cold';
    return { ...themes[key], key };
  }
  window.SkyRibbonWeatherTheme = Object.freeze({ getTheme, category, themes });
})();
